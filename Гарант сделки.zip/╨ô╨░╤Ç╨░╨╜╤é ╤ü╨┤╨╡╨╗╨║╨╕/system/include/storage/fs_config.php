<?php
return array (
  'meta' => 
  array (
    'title' => 
    array (
      'type' => 'string',
      'length' => 127,
      'value' => '',
    ),
    'email' => 
    array (
      'type' => 'string',
      'length' => 127,
      'value' => '',
    ),
    'subject' => 
    array (
      'type' => 'string',
      'length' => 127,
      'value' => '',
    ),
    'from' => 
    array (
      'type' => 'string',
      'length' => 127,
      'value' => '',
    ),
    'template' => 
    array (
      'type' => 'string',
      'length' => 16383,
      'value' => '',
    ),
    'fields' => 
    array (
      'type' => 'array',
    ),
    'form_fields' => 
    array (
      'type' => 'string',
      'length' => 16383,
      'value' => '',
    ),
    'form_action' => 
    array (
      'type' => 'string',
      'length' => 2047,
      'value' => '',
    ),
    'selector' => 
    array (
      'type' => 'string',
      'length' => 1023,
      'value' => '',
    ),
    'msg_success' => 
    array (
      'type' => 'string',
      'length' => 127,
      'value' => '',
    ),
    'async_headers' => 
    array (
      'type' => 'array',
      'value' => 
      array (
      ),
    ),
    'async_response' => 
    array (
      'type' => 'string',
      'length' => 16383,
      'value' => '',
    ),
  ),
  'data' => 
  array (
  ),
  'keys' => 
  array (
  ),
);
?>