$(document).ready(function(){
  $(window).scroll(function(){
    var scrollTop = $(window).scrollTop();
    if (scrollTop > 49) {
        $('#wrappercon').addClass('header-fixed');
    } else {
        $('#wrappercon').removeClass('header-fixed');
    }
  });
});